int g(n){
  return 3*n*n - 4*n +8;
}