#include <stdio.h>

int g(int);
int main(){
  printf("g(%d) = %d\n",3,g(3));
}