int g(int n){
  return n*n;
}