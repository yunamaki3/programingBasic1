#ifndef HEADER_H
#define HEADER_H

#define N 5

int f(int n);
int g(int n);

#endif