int f(n){
  return n*n + 4*n + 3;
}