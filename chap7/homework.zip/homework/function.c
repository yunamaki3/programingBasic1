#include <math.h>
void calcDeviation(int *x,int num){
  int total = 0;
  for (int i=0; i<num; i++){
    total += *(x+i);
  }
  int avg = total / num;
  int s = 0;
  for (int j=0; j<num; j++){
    int hensa = *(x+j)-avg;
    s += hensa*hensa;
  }
  int bunsan = sqrt(s / num);

  for(int k=0; k<num; k++){
    *(x+k) = 10 * (*(x+k)-avg) / bunsan + 50;
  }
}