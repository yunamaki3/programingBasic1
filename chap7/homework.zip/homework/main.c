#include <stdio.h>
#include "header.h"

int main(){
  //変数宣言
  int x[N];

  //点数のユーザー入力
  for (int i=0; i<N; i++){
    printf("%d人目の点数を入力してください -> ",i+1);
    scanf("%d",&x[i]);
  }

  calcDeviation(&x[0],N);

  for (int j=0; j<N; j++){
    printf("%d人目の偏差値は%dです。\n",j+1,x[j]);
  }
}