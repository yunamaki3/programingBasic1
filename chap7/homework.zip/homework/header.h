#ifndef HEADER_H
#define HEADER_H

//学生人数の指定
#define N 5

void calcDeviation(int *,int);

#endif